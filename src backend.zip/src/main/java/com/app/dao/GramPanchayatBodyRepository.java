package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.app.pojos.GramPanchayatBody;

public interface GramPanchayatBodyRepository extends JpaRepository<GramPanchayatBody, Integer> {

}
