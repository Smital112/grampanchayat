package com.app.exceptions;

public class ActorException extends RuntimeException {

	public ActorException(String mesg) {
		super(mesg);
	}
}
