import React from "react";

import Allschemes from "./Allschemes";

const Scheme =({scheme})=> {
 return (
     <div>
         <table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Descripion</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    
  </tbody>
</table>
     </div>
     
 )
}
export default Scheme;